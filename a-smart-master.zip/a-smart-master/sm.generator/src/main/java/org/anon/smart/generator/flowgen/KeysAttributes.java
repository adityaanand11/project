package org.anon.smart.generator.flowgen;

public class KeysAttributes {

	private String data;
	private String key;
	
	public KeysAttributes(String data, String key) {
		super();
		this.data = data;
		this.key = key;
	}
	
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	public KeysAttributes() {
		// TODO Auto-generated constructor stub
	}

}
