package org.anon.smart.d2cache.store.repository.hbase.test;

public class HBaseCRUDTestSuite {

}
